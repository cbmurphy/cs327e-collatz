Project #1: Collatz
Date: Wed, 30 Jan 2013, 8pm

Course Name: CS327E
Unique: 53355

First Name: Collin
Last Name: Murphy
EID: cbm772
E-mail: cbmurphy@utexas.edu
Estimated number of hours: 15
Actual    number of hours: 25

Turnin CS Username: cbm772
GitHub ID: cbmurphy
GitHub Repository Name: cs327e-Collatz

Comments:

---------------
Code of Conduct
---------------

I attest that I have written every line of code that I have submitted
and I take full responsibility for the origin of all the code submitted.
In particular, if any of the code was originally written in a previous
semester or another course I will so acknowledge via e-mail to the
grader.
